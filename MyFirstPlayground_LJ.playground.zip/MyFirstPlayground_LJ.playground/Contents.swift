import UIKit
//Hands On B
import Foundation

var numberOfLike = 10000
var numberOfComments = 888
let yearCreated = 2019
let monthCreated = 4
let dayCreated = 12

//Hands On C
let name = "Eky"
var age = 21
var numberOfStepTakenToday = 1000
var goalNumberOfStep = 1001
var averageHeartRate = 80

//Latihan
var str = "Hello, playground"
print(str)

let defaultScore = 100
var playerOneScore = defaultScore
var playerTwoScore = defaultScore

print(playerOneScore)
print(playerTwoScore)

playerOneScore=200
print(playerOneScore)
//assignment
var x : Int //declare
x = 10 //assignment
print(x)


//hands on
let friends : Int = 999
print(friends-20)

var friend : Int = 200
friend = 180
print(friend)

//Hands On D
var firstDecimal = 2.5
var secondDecimal = 3.5

var trueOrFalse = true
var stringValue = "anis"

firstDecimal = 10
print(firstDecimal)

var hasMetStepGoal = false

firstDecimal += 3
print(firstDecimal)

var halo = "halo"
//Merubah satu nilai ke tipe data yang lain
let x1 = 3
let y = 3.1444
let z = Double(x1) + y
print(z)

//Penulisan multivariabel dalam satu line menggunakan Tuples

